<?php

get_header();

bridge_qode_get_title();

qode_lms_get_single_lesson();

get_footer();