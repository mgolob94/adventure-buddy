<div class="qodef-re-author-image">
	<?php echo qodef_re_get_author_image($author->ID, $author->roles, 'bridge_qode_square', '550'); ?>
</div>