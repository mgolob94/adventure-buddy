<?php

get_header();

bridge_qode_get_title();

qodef_re_get_single_property();

get_footer();