<?php
require_once 'property-slider.php';
require_once 'helper-functions.php';