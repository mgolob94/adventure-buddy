<?php
require_once 'property-search.php';
require_once 'helper-functions.php';