<div class="qodef-pts-item-image">
    <?php echo qodef_re_get_taxonomy_featured_image($id, 'property_type_featured_image', $image_proportions); ?>
</div>
<h6 class="qodef-pts-item-title">
    <?php echo esc_html($name); ?>
</h6>
