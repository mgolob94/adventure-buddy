<?php
require_once 'property-single.php';
require_once 'helper-functions.php';