<?php

include_once QODE_RESTAURANT_CPT_PATH.'/restaurant-menu/restaurant-menu-register.php';
include_once QODE_RESTAURANT_CPT_PATH.'/restaurant-menu/helper-functions.php';
include_once QODE_RESTAURANT_CPT_PATH.'/restaurant-menu/shortcodes/shortcodes-functions.php';