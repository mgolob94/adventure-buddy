<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/portfolio-carousel/portfolio-carousel.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/portfolio-carousel/helper-functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/portfolio-carousel/custom-styles/custom-styles.php';