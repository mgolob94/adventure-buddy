<p class="qode-ls-not-found">
    <?php esc_html_e( "Sorry, you don't have any packages.", 'qode-listing' );?>
</p>