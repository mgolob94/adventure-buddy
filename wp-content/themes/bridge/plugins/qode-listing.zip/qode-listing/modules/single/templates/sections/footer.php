<div class="qode-ls-single-footer grid_section">
	<div class="section_inner clearfix">
		<div class="qode-ls-single-section">
			<?php echo qode_listing_single_template_part('parts/related-posts');?>
		</div>
	</div>
</div>